"""
Publicador · El Chapucero  (servidor local)
-------------------------------------------
- Muestra el panel en el navegador (http://127.0.0.1:7880).
- Habla con el n8n de Render por webhooks (con la clave X-Clave):
      GET  {n8n}/videos              lista de videos de la carpeta de Drive
      GET  {n8n}/descargar?id=...    el video original
      GET  {n8n}/miniatura?id=...    miniatura (respaldo si Google no la entrega directo)
      POST {n8n}/subida              crea una subida directa a Drive (reemplaza el archivo, mismo ID)
      POST {n8n}/renombrar           cambia el nombre del archivo en Drive
      POST {n8n}/hs-media            crea la subida del video en Hootsuite (el video se sube directo desde la PC)
      GET  {n8n}/hs-media-estado     revisa si Hootsuite ya procesó el video (READY)
      POST {n8n}/hs-mensaje          crea la publicación en las cuentas elegidas en el panel
      GET  {n8n}/perfiles            cuentas conectadas en Hootsuite (para ver sus IDs)
      POST {n8n}/marcar              guarda en el archivo de Drive en qué cuentas se publicó
      POST {n8n}/mover               mueve el video a la carpeta «Videos Subidos»
- Los videos que se ven o se editan se guardan en caché en esta PC (se descargan una sola vez).
- El cambio de título se renderiza AQUÍ con ffmpeg (NVENC si hay tarjeta NVIDIA).
"""
import base64
import hashlib
import json
import mimetypes
import os
import shutil
import subprocess
import tempfile
import threading
import time
import traceback
import uuid
from pathlib import Path

import requests
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response

APP = Path(__file__).resolve().parent
RAIZ = APP.parent
CONFIG_PATH = RAIZ / "config.json"
DATOS = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "PublicadorChapucero"
TRABAJOS_DIR = DATOS / "trabajos"
CACHE_VIDEOS = DATOS / "cache_videos"
CACHE_MINIS = DATOS / "cache_miniaturas"
for d in (TRABAJOS_DIR, CACHE_VIDEOS, CACHE_MINIS):
    d.mkdir(parents=True, exist_ok=True)
LOG = DATOS / "registro.log"
SIN_VENTANA = 0x08000000 if os.name == "nt" else 0
CACHE_MAX_GB = 5          # tamaño máximo de la caché de videos
CACHE_MAX_ARCHIVOS = 30

# Límites por red al publicar a través de Hootsuite
# (duración en segundos, peso en MB, texto en caracteres, bitrate de audio en kbps).
# Si una red cambia sus límites, se ajusta aquí y se manda la actualización.
LIMITES = {
    "facebook":  {"nombre": "Facebook",  "dur_min": 3,   "dur_max": 90,  "mb": 1024, "texto": 63206, "audio_kbps": 128},
    "instagram": {"nombre": "Instagram", "dur_min": 3,   "dur_max": 900, "mb": 300,  "texto": 2200,  "audio_kbps": 128},
    "x":         {"nombre": "X",         "dur_min": 0.5, "dur_max": 140, "mb": 512,  "texto": 280,   "audio_kbps": 128},
}
TOLERANCIA_AUDIO_KBPS = 0.5   # 128.4 kbps cuenta como 128
MAX_PUBLICACIONES_A_LA_VEZ = 2
MAX_REVISIONES_A_LA_VEZ = 3
ESTADOS_ACTIVOS = ("en_cola", "descargando", "renderizando", "subiendo", "validando", "subiendo_hs", "procesando_hs", "programando")

POR_DEFECTO = {
    "n8n_url": "",          # ej. https://tu-n8n.onrender.com/webhook  (o /webhook-test para pruebas)
    "clave": "",            # la misma que la credencial "Header Auth" de n8n
    "puerto": 7880,
    "gpu_nvenc": False,
    "url_actualizacion": "",
    "ids_cuentas": {},      # opcional: forzar el ID de Hootsuite de una cuenta fija, ej. {"fb_izquierda": "123456"}
}

# Cuentas donde se publica (fijas), con su ID de Hootsuite.
# Si en algún momento cambia un ID, se corrige aquí (o en config.json → "ids_cuentas") y se manda la actualización.
CUENTAS_FIJAS = [
    {"clave": "fb_chapucero", "red": "facebook",  "nombre": "El Chapucero",       "id": "140510827"},
    {"clave": "fb_izquierda", "red": "facebook",  "nombre": "Izquierda Noticias", "id": "140504880"},
    {"clave": "x_chapucero",  "red": "x",         "nombre": "El Chapucero",       "id": "140238459"},
    {"clave": "x_izquierda",  "red": "x",         "nombre": "Izquierda Noticias", "id": "140302370"},
    {"clave": "ig_chapucero", "red": "instagram", "nombre": "El Chapucero",       "id": "140238463"},
]

# Tipo de cuenta de Hootsuite -> red del Publicador (las que no estén aquí aún no se pueden usar)
TIPOS_HOOTSUITE = {
    "FACEBOOKPAGE": "facebook", "FACEBOOK": "facebook",
    "INSTAGRAMBUSINESS": "instagram", "INSTAGRAM": "instagram",
    "TWITTER": "x", "X": "x",
}

app = FastAPI(title="Publicador Chapucero")
trabajos = {}               # id -> {estado, mensaje, fileId, nombre, inicio}
candado = threading.Lock()
candados_descarga = {}      # fileId -> Lock (para no bajar el mismo video dos veces a la vez)
cupo_publicar = threading.Semaphore(MAX_PUBLICACIONES_A_LA_VEZ)


# ----------------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------------
def log(txt):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S  ") + txt + "\n")
    except OSError:
        pass


def leer_config():
    cfg = dict(POR_DEFECTO)
    if CONFIG_PATH.exists():
        try:
            cfg.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig")))
        except Exception:
            pass
    return cfg


def guardar_config(cambios):
    cfg = leer_config()
    cfg.update(cambios)
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return cfg


def n8n(ruta):
    cfg = leer_config()
    base = (cfg.get("n8n_url") or "").strip().rstrip("/")
    if not base or not cfg.get("clave"):
        raise HTTPException(400, "config")
    return base + "/" + ruta.lstrip("/"), {"X-Clave": cfg["clave"]}


def actualizar_trabajo(tid, **datos):
    with candado:
        trabajos[tid].update(datos)


def llave(file_id, modificado):
    """Nombre de caché: cambia cuando el archivo cambia en Drive."""
    h = hashlib.md5(f"{file_id}|{modificado or ''}".encode()).hexdigest()[:10]
    return f"{file_id}_{h}"


def limpiar_cache():
    archivos = sorted((p for p in CACHE_VIDEOS.glob("*") if p.is_file() and not p.name.endswith(".parcial")),
                      key=lambda p: p.stat().st_atime, reverse=True)
    total = 0
    for i, p in enumerate(archivos):
        total += p.stat().st_size
        if i >= CACHE_MAX_ARCHIVOS or total > CACHE_MAX_GB * 1024 ** 3:
            p.unlink(missing_ok=True)


def borrar_cache_de(file_id):
    for p in list(CACHE_VIDEOS.glob(f"{file_id}_*")) + list(CACHE_MINIS.glob(f"{file_id}_*")):
        p.unlink(missing_ok=True)


def obtener_original(file_id, modificado, nombre):
    """Regresa la ruta local del video (lo descarga de n8n solo si no está en caché)."""
    ext = Path(nombre or "video.mp4").suffix.lower() or ".mp4"
    destino = CACHE_VIDEOS / f"{llave(file_id, modificado)}{ext}"
    with candado:
        lk = candados_descarga.setdefault(file_id, threading.Lock())
    with lk:
        if destino.exists() and destino.stat().st_size > 1000:
            os.utime(destino)
            return destino
        for viejo in CACHE_VIDEOS.glob(f"{file_id}_*"):   # versiones anteriores del mismo archivo
            viejo.unlink(missing_ok=True)
        parcial = destino.with_name(destino.name + ".parcial")
        url, hdr = n8n("descargar")
        with requests.get(url, headers=hdr, params={"id": file_id}, stream=True, timeout=(15, 600)) as r:
            if r.status_code != 200:
                raise RuntimeError(f"n8n no entregó el video (HTTP {r.status_code}): {r.text[:200]}")
            with open(parcial, "wb") as f:
                for trozo in r.iter_content(1024 * 1024):
                    f.write(trozo)
        if parcial.stat().st_size < 1000:
            parcial.unlink(missing_ok=True)
            raise RuntimeError("El video descargado está vacío.")
        parcial.replace(destino)
    limpiar_cache()
    return destino


def medidas(ruta):
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height", "-of", "json", str(ruta)],
        capture_output=True, text=True, creationflags=SIN_VENTANA)
    if r.returncode != 0:
        raise RuntimeError("No se pudo leer el video descargado: " + r.stderr[-300:])
    s = json.loads(r.stdout)["streams"][0]
    return int(s["width"]), int(s["height"])


def info_video(ruta):
    """Duración (s), peso (MB) y bitrate de audio (kbps, None si no tiene audio) del archivo real."""
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,bit_rate",
         "-of", "json", str(ruta)],
        capture_output=True, text=True, creationflags=SIN_VENTANA)
    try:
        d = json.loads(r.stdout)
        dur = float(d["format"]["duration"])
    except Exception:
        raise RuntimeError("No se pudo leer el video con ffprobe.")
    audios = [s for s in d.get("streams", []) if s.get("codec_type") == "audio"]
    kbps = None
    if audios:
        br = audios[0].get("bit_rate")
        if br and str(br).isdigit():
            kbps = int(br) / 1000
        else:
            # el contenedor no trae el dato: se calcula sumando los paquetes de audio
            r = subprocess.run(
                ["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "packet=size",
                 "-of", "csv=p=0", str(ruta)],
                capture_output=True, text=True, creationflags=SIN_VENTANA)
            total = sum(int(x) for x in r.stdout.split() if x.strip().isdigit())
            kbps = (total * 8 / dur / 1000) if dur else None
    return {"duracion": dur, "mb": Path(ruta).stat().st_size / 1024 / 1024,
            "audio_kbps": round(kbps, 1) if kbps is not None else None}


def fmt_tiempo(seg):
    seg = int(round(seg))
    return f"{seg // 60}:{seg % 60:02d}"


def problemas_por_red(red, dur, mb, texto, audio_kbps=None):
    """Lista de motivos por los que el video NO se puede mandar a esa red (vacía = sí se puede)."""
    L = LIMITES[red]
    p = []
    if dur is not None and dur > L["dur_max"]:
        p.append(f"dura {fmt_tiempo(dur)} y el máximo es {fmt_tiempo(L['dur_max'])}")
    if dur is not None and dur < L["dur_min"]:
        p.append(f"dura {dur:.1f} s y el mínimo es {L['dur_min']} s")
    if mb is not None and mb > L["mb"]:
        p.append(f"pesa {mb:.0f} MB y el máximo es {L['mb']} MB")
    if audio_kbps is not None and audio_kbps > L["audio_kbps"] + TOLERANCIA_AUDIO_KBPS:
        p.append(f"el audio va a {audio_kbps:.0f} kbps y el máximo es {L['audio_kbps']} kbps")
    if texto is not None and len(texto) > L["texto"]:
        p.append(f"el texto tiene {len(texto)} caracteres y el máximo es {L['texto']}")
    return p


def resolver_cuentas(forzar=False):
    """Las cuentas fijas con su ID de Hootsuite (config.json → "ids_cuentas" tiene prioridad)."""
    manuales = leer_config().get("ids_cuentas") or {}
    salida = []
    for c in CUENTAS_FIJAS:
        cid = str(manuales.get(c["clave"]) or c.get("id") or "").replace("socialProfile/", "").strip()
        salida.append({"clave": c["clave"], "red": c["red"], "nombre": c["nombre"],
                       "id": cid or None, "problema": None if cid else "Falta su ID de Hootsuite"})
    return salida


def etiqueta_cuenta(c):
    return f"{LIMITES.get(c['red'], {}).get('nombre', c['red'])} ({c.get('nombre', '')})"


def n8n_json(ruta, metodo="GET", **kw):
    url, hdr = n8n(ruta)
    r = requests.request(metodo, url, headers=hdr, timeout=kw.pop("timeout", 60), **kw)
    try:
        d = r.json()
    except ValueError:
        d = {}
    if r.status_code != 200 or d.get("ok") is False:
        raise RuntimeError(d.get("error") or f"n8n respondió HTTP {r.status_code}: {r.text[:200]}")
    return d


def codificador():
    if leer_config().get("gpu_nvenc"):
        return ["-c:v", "h264_nvenc", "-preset", "p5", "-cq", "19", "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p"]


def renderizar(video, capa, salida, desde):
    """Pone la capa (barra roja + título, PNG 1080x1920) sobre el video, escalada al ancho y pegada arriba."""
    W, _ = medidas(video)
    activar = f":enable='gte(t,{desde:.3f})'" if desde > 0 else ""
    filtro = f"[1:v]scale={W}:-1[t];[0:v][t]overlay=0:0{activar}[v]"
    base = ["ffmpeg", "-y", "-v", "error", "-i", str(video), "-i", str(capa),
            "-filter_complex", filtro, "-map", "[v]", "-map", "0:a?"]
    fin = ["-c:a", "copy", "-movflags", "+faststart", str(salida)]
    r = subprocess.run(base + codificador() + fin, capture_output=True, text=True, creationflags=SIN_VENTANA)
    if r.returncode != 0 and leer_config().get("gpu_nvenc"):
        log("NVENC falló, reintento con el procesador: " + r.stderr[-300:])
        r = subprocess.run(base + ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p"] + fin,
                           capture_output=True, text=True, creationflags=SIN_VENTANA)
    if r.returncode != 0 or not Path(salida).exists():
        raise RuntimeError("ffmpeg falló: " + r.stderr[-500:])


# ----------------------------------------------------------------------------
# Trabajo de cambio de título (en segundo plano)
# ----------------------------------------------------------------------------
def trabajo_titulo(tid, file_id, nombre, modificado, desde, png_b64):
    carpeta = Path(tempfile.mkdtemp(prefix="titulo_", dir=TRABAJOS_DIR))
    try:
        capa = carpeta / "capa.png"
        capa.write_bytes(base64.b64decode(png_b64))
        salida = carpeta / "salida.mp4"

        # 1) Original (de la caché, o se descarga a través de n8n)
        actualizar_trabajo(tid, estado="descargando", mensaje="Descargando video…")
        original = obtener_original(file_id, modificado, nombre)

        # 2) Renderizar
        actualizar_trabajo(tid, estado="renderizando", mensaje="Poniendo el título…")
        renderizar(original, capa, salida, desde)

        # 3) Pedir a n8n una subida directa a Drive y subir (reemplaza el archivo, mismo ID)
        actualizar_trabajo(tid, estado="subiendo", mensaje="Subiendo a Drive…")
        tam = salida.stat().st_size
        url, hdr = n8n("subida")
        r = requests.post(url, headers=hdr, json={"fileId": file_id, "tamano": tam, "mimeType": "video/mp4"}, timeout=60)
        if r.status_code != 200:
            raise RuntimeError(f"n8n no creó la subida (HTTP {r.status_code}): {r.text[:200]}")
        upload_url = (r.json() or {}).get("uploadUrl")
        if not upload_url:
            raise RuntimeError("n8n no regresó la dirección de subida.")
        with open(salida, "rb") as f:
            r = requests.put(upload_url, data=f, headers={"Content-Length": str(tam), "Content-Type": "video/mp4"},
                             timeout=(15, 1800))
        if r.status_code not in (200, 201):
            raise RuntimeError(f"Drive rechazó la subida (HTTP {r.status_code}): {r.text[:200]}")

        borrar_cache_de(file_id)   # el archivo cambió: la próxima vez se ve la versión nueva
        actualizar_trabajo(tid, estado="listo", mensaje="Título cambiado ✓", fin=time.time())
        log(f"Título cambiado: {nombre} ({file_id})")
    except Exception as e:
        log(f"Error cambiando título de {nombre}: {traceback.format_exc()}")
        actualizar_trabajo(tid, estado="error", mensaje=str(e), fin=time.time())
    finally:
        shutil.rmtree(carpeta, ignore_errors=True)


# ----------------------------------------------------------------------------
# Copias por red y subida a Hootsuite
# ----------------------------------------------------------------------------
# Redes que pueden necesitar otra resolución. Se prueba en orden, de mayor a menor calidad,
# y se usa la primera que la red acepte (None = el video original, sin tocar).
# X: el original 1080x1920 solo lo aceptan algunas cuentas (Premium); el máximo vertical general es 1200x1900
# y el tamaño recomendado 720x1280. Facebook e Instagram siempre reciben el original.
REDES_CON_COPIA = {
    "x": [None, {"max_w": 1200, "max_h": 1900, "fps": 30}, {"max_w": 720, "max_h": 1280, "fps": 30}],
}


def copia_para_red(ruta, red, cfg):
    destino = Path(ruta).with_name(Path(ruta).stem + f"__{red}_{cfg['max_w']}x{cfg['max_h']}.mp4")
    if destino.exists() and destino.stat().st_size > 1000 and destino.stat().st_mtime >= Path(ruta).stat().st_mtime:
        return destino
    filtro = (f"scale='min({cfg['max_w']},iw)':'min({cfg['max_h']},ih)':force_original_aspect_ratio=decrease:flags=lanczos,"
              f"scale=trunc(iw/2)*2:trunc(ih/2)*2,setsar=1,fps={cfg['fps']}")
    tmp = destino.with_name(destino.name + ".parcial.mp4")
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", str(ruta), "-vf", filtro,
           "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-profile:v", "high", "-pix_fmt", "yuv420p",
           "-maxrate", "20M", "-bufsize", "40M", "-g", str(cfg["fps"] * 2),
           "-c:a", "aac", "-b:a", "126k", "-ac", "2", "-ar", "44100",
           "-movflags", "+faststart", str(tmp)]
    r = subprocess.run(cmd, capture_output=True, text=True, creationflags=SIN_VENTANA)
    if r.returncode != 0 or not tmp.exists():
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"No se pudo preparar la copia para {LIMITES[red]['nombre']}: " + r.stderr[-300:])
    tmp.replace(destino)
    return destino


# Hootsuite necesita margen para procesar el video antes de publicarlo: si rechaza la hora,
# se reintenta (con el mismo video ya subido) programándolo más adelante.
MINUTOS_REINTENTO = [6, 20, 40, 65]


def publicar_grupo(tid, archivo, del_grupo, texto, fecha, nombre, carpeta):
    etiquetas = ", ".join(etiqueta_cuenta(c) for c in del_grupo)
    actualizar_trabajo(tid, estado="subiendo_hs", mensaje=f"Subiendo a Hootsuite ({etiquetas})…")
    media_id = subir_a_hootsuite(tid, archivo)
    ultimo = None
    for minutos in MINUTOS_REINTENTO:
        actualizar_trabajo(tid, estado="programando",
                           mensaje=f"Creando la publicación ({etiquetas})…" if minutos == MINUTOS_REINTENTO[0]
                           else f"Hootsuite pidió más tiempo; programando a {minutos} min ({etiquetas})…")
        try:
            return n8n_json("hs-mensaje", "POST", timeout=120, json={
                "mediaId": media_id, "texto": texto, "perfiles": [str(c["id"]) for c in del_grupo],
                "fecha": fecha, "minutos": minutos, "nombre": nombre, "carpeta": carpeta})
        except Exception as e:
            ultimo = e
            if "HTTP 400" not in str(e):
                raise
            log(f"Hootsuite rechazó {nombre} a {minutos} min: {e}")
    raise ultimo


def hora_programada(detalle):
    """La hora real que quedó en Hootsuite (UTC), tomada de la respuesta."""
    for d in detalle if isinstance(detalle, list) else [detalle]:
        for m in (d or {}).get("mensajes", []) or []:
            if m.get("hora"):
                return m["hora"]
    return None


def hora_local(iso):
    try:
        import datetime as _dt
        t = _dt.datetime.strptime(iso, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=_dt.timezone.utc).astimezone()
        return t.strftime("%d/%m %I:%M %p").lower()
    except Exception:
        return iso


def subir_a_hootsuite(tid, archivo):
    """Sube el archivo directo desde la PC a Hootsuite y espera a que esté READY. Regresa el mediaId."""
    archivo = Path(archivo)
    tam = archivo.stat().st_size
    mime = mimetypes.guess_type(str(archivo))[0] or "video/mp4"
    d = n8n_json("hs-media", "POST", json={"sizeBytes": tam, "mimeType": mime})
    media_id, upload_url = d.get("id"), d.get("uploadUrl")
    if not media_id or not upload_url:
        raise RuntimeError("Hootsuite no entregó la dirección de subida.")
    with open(archivo, "rb") as f:
        r = requests.put(upload_url, data=f, timeout=(15, 1800),
                         headers={"Content-Type": mime, "Content-Length": str(tam)})
    if r.status_code not in (200, 201, 204):
        raise RuntimeError(f"Hootsuite rechazó el video (HTTP {r.status_code}).")
    actualizar_trabajo(tid, estado="procesando_hs", mensaje="Hootsuite procesando el video…")
    limite = time.time() + 600
    while True:
        estado = (n8n_json("hs-media-estado", params={"id": media_id}).get("state") or "").upper()
        if estado == "READY":
            return media_id
        if estado in ("FAILED", "ERROR", "REJECTED"):
            raise RuntimeError(f"Hootsuite no pudo procesar el video ({estado}).")
        if time.time() > limite:
            raise RuntimeError("Hootsuite tardó más de 10 minutos en procesar el video.")
        time.sleep(5)


# ----------------------------------------------------------------------------
# Trabajo de publicación (en segundo plano)
# ----------------------------------------------------------------------------
def trabajo_publicar(tid, v, fecha):
    file_id, nombre = v["id"], v.get("nombre", "")
    # solo cuentas configuradas (no se confía ciegamente en lo que manda el navegador)
    configuradas = {str(c["id"]): c for c in resolver_cuentas() if c.get("id")}
    cuentas = [configuradas[str(c)] for c in v.get("cuentas", []) if str(c) in configuradas]
    texto = v.get("texto", "")
    try:
        actualizar_trabajo(tid, estado="en_cola", mensaje="Esperando turno para publicar…")
        with cupo_publicar:
            # 1) Video (de la caché o descargado una vez)
            actualizar_trabajo(tid, estado="descargando", mensaje="Preparando video…")
            ruta = obtener_original(file_id, v.get("modificado", ""), nombre)

            # 2) Validación final con el archivo real
            actualizar_trabajo(tid, estado="validando", mensaje="Revisando límites…")
            inf, tam = info_video(ruta), ruta.stat().st_size
            if not cuentas:
                raise RuntimeError("No hay cuentas válidas elegidas.")
            omitidas, permitidas = [], []
            for c in cuentas:
                p = problemas_por_red(c["red"], inf["duracion"], inf["mb"], texto, inf["audio_kbps"])
                (omitidas if p else permitidas).append((c, p))
            permitidas = [c for c, _ in permitidas]
            nota = "; ".join(f"{etiqueta_cuenta(c)}: {', '.join(p)}" for c, p in omitidas)
            if not permitidas:
                raise RuntimeError("No se puede publicar en ninguna cuenta. " + nota)

            # 3) Facebook / Instagram: video original. X: original y, si lo rechaza, la mejor copia que acepte.
            enviadas, fallidas, detalle, notas_res, horas = [], [], [], [], {}
            carpeta = v.get("carpeta", "")
            originales = [c for c in permitidas if c["red"] not in REDES_CON_COPIA]
            if originales:
                try:
                    d_ = publicar_grupo(tid, ruta, originales, texto, fecha, nombre, carpeta)
                    detalle.append(d_)
                    for c in originales:
                        horas[c["id"]] = hora_programada(d_)
                    enviadas += originales
                except Exception as e:
                    log(f"Falló el envío original de {nombre}: {e}")
                    fallidas.append((originales, str(e)))

            for red, variantes in REDES_CON_COPIA.items():
                de_red = [c for c in permitidas if c["red"] == red]
                if not de_red:
                    continue
                ultimo_error = None
                for cfg in variantes:
                    try:
                        if cfg is None:
                            archivo, desc = ruta, "original"
                        else:
                            actualizar_trabajo(tid, estado="validando",
                                               mensaje=f"{LIMITES[red]['nombre']} no aceptó la versión anterior; preparando una copia más pequeña…")
                            archivo = copia_para_red(ruta, red, cfg)
                            w, h = medidas(archivo)
                            desc = f"{w}×{h}"
                        d_ = publicar_grupo(tid, archivo, de_red, texto, fecha, nombre, carpeta)
                        detalle.append(d_)
                        for c in de_red:
                            horas[c["id"]] = hora_programada(d_)
                        enviadas += de_red
                        if cfg is not None:
                            notas_res.append(f"{LIMITES[red]['nombre']} con copia {desc}")
                        ultimo_error = None
                        break
                    except Exception as e:
                        ultimo_error = str(e)
                        log(f"{LIMITES[red]['nombre']} rechazó {('el original' if cfg is None else cfg)} de {nombre}: {e}")
                        if "HTTP 400" not in ultimo_error:
                            break   # no es rechazo del video (cuenta, conexión…): no tiene caso probar otra resolución
                if ultimo_error:
                    fallidas.append((de_red, ultimo_error))

            if not enviadas:
                raise RuntimeError("; ".join(f"{', '.join(etiqueta_cuenta(c) for c in g)}: {e}" for g, e in fallidas))

            nombres = ", ".join(etiqueta_cuenta(c) for c in enviadas)
            horas_txt = sorted({hora_local(h) for h in horas.values() if h})
            msg = f"Programado en {nombres}" + (f" para {', '.join(horas_txt)}" if horas_txt else "") + " ✓"
            if notas_res:
                msg += " (" + "; ".join(notas_res) + ")"
            if fallidas:
                msg += " · FALLÓ: " + "; ".join(f"{', '.join(etiqueta_cuenta(c) for c in g)} ({e})" for g, e in fallidas)
            if nota:
                msg += f" (no se mandó a {nota})"

            # 6) Marca en el archivo de Drive (la ven todas las PCs), solo de lo que sí se envió
            ahora = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            marcas = {f"pub_{c['id']}": f"{c['red']}|programado|{horas.get(c['id']) or fecha or ahora}|{c.get('nombre', '')}"[:110]
                      for c in enviadas}
            try:
                n8n_json("marcar", "POST", json={"fileId": file_id, "marcas": marcas})
            except Exception as e:
                log(f"No se pudo guardar la marca de {nombre}: {e}")
                msg += " (ojo: no se pudo guardar la marca en Drive)"
            d = detalle
            actualizar_trabajo(tid, estado="listo", mensaje=msg, fin=time.time(), detalle=d)
            log(f"Publicado {nombre} ({file_id}) en {nombres}. Omitidas: {nota or '-'}. Fallidas: {fallidas or '-'}")
    except Exception as e:
        log(f"Error publicando {nombre}: {traceback.format_exc()}")
        actualizar_trabajo(tid, estado="error", mensaje=str(e), fin=time.time())


# ----------------------------------------------------------------------------
# Rutas
# ----------------------------------------------------------------------------
@app.get("/")
def inicio():
    return FileResponse(APP / "web" / "panel.html", headers={"Cache-Control": "no-store"})


@app.get("/assets/{nombre}")
def assets(nombre: str):
    ruta = (APP / "assets" / nombre).resolve()
    if not str(ruta).startswith(str((APP / "assets").resolve())) or not ruta.exists():
        raise HTTPException(404)
    return FileResponse(ruta)


@app.get("/api/vivo")
def vivo():
    return {"ok": True, "version": (APP / "version.txt").read_text(encoding="utf-8").strip()}


@app.get("/api/config")
def ver_config():
    cfg = leer_config()
    return {"n8n_url": cfg.get("n8n_url", ""), "tiene_clave": bool(cfg.get("clave")),
            "gpu_nvenc": cfg.get("gpu_nvenc", False),
            "version": (APP / "version.txt").read_text(encoding="utf-8").strip()}


@app.post("/api/config")
async def cambiar_config(req: Request):
    d = await req.json()
    cambios = {}
    if "n8n_url" in d:
        cambios["n8n_url"] = str(d["n8n_url"]).strip().rstrip("/")
    if d.get("clave"):
        cambios["clave"] = str(d["clave"]).strip()
    guardar_config(cambios)
    return ver_config()


@app.get("/api/videos")
def videos():
    url, hdr = n8n("videos")
    try:
        r = requests.get(url, headers=hdr, timeout=60)
    except requests.RequestException as e:
        raise HTTPException(502, f"No hay conexión con n8n: {e}")
    if r.status_code in (401, 403):
        raise HTTPException(401, "La clave no es correcta.")
    if r.status_code != 200:
        raise HTTPException(502, f"n8n respondió HTTP {r.status_code}")
    return JSONResponse(r.json())


@app.get("/api/miniatura/{file_id}")
def miniatura(file_id: str, m: str = "", u: str = ""):
    """Miniatura con caché local. Primero intenta directo con Google; si no, a través de n8n."""
    ruta = CACHE_MINIS / f"{llave(file_id, m)}.img"
    if not ruta.exists():
        datos, tipo = None, "image/jpeg"
        if u:
            try:
                r = requests.get(u.split("=s")[0] + "=s480" if "=s" in u else u, timeout=15)
                if r.status_code == 200 and r.headers.get("content-type", "").startswith("image/"):
                    datos, tipo = r.content, r.headers["content-type"]
            except requests.RequestException:
                pass
        if datos is None:
            try:
                url, hdr = n8n("miniatura")
                r = requests.get(url, headers=hdr, params={"id": file_id}, timeout=30)
                if r.status_code == 200 and r.headers.get("content-type", "").startswith("image/"):
                    datos, tipo = r.content, r.headers["content-type"]
            except (requests.RequestException, HTTPException):
                pass
        if datos is None:
            raise HTTPException(404, "Sin miniatura")
        for viejo in CACHE_MINIS.glob(f"{file_id}_*"):
            viejo.unlink(missing_ok=True)
        ruta.write_bytes(datos)
        ruta.with_suffix(".tipo").write_text(tipo)
    tipo_p = ruta.with_suffix(".tipo")
    tipo = tipo_p.read_text() if tipo_p.exists() else "image/jpeg"
    return Response(ruta.read_bytes(), media_type=tipo, headers={"Cache-Control": "max-age=86400"})


@app.get("/api/ver/{file_id}")
def ver(file_id: str, m: str = "", nombre: str = "video.mp4"):
    """Entrega el video para el reproductor (lo descarga una vez y queda en caché)."""
    try:
        ruta = obtener_original(file_id, m, nombre)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, str(e))
    tipo = mimetypes.guess_type(str(ruta))[0] or "video/mp4"
    return FileResponse(ruta, media_type=tipo)


@app.post("/api/renombrar")
async def renombrar(req: Request):
    d = await req.json()
    file_id = d.get("fileId")
    nuevo = str(d.get("nombre") or "").strip()
    anterior = str(d.get("anterior") or "")
    if not file_id or not nuevo:
        raise HTTPException(400, "Falta el nombre")
    for c in '\\/:*?"<>|':
        nuevo = nuevo.replace(c, "-")
    ext = Path(anterior).suffix
    if ext and not nuevo.lower().endswith(ext.lower()):
        nuevo += ext
    url, hdr = n8n("renombrar")
    try:
        r = requests.post(url, headers=hdr, json={"fileId": file_id, "nombre": nuevo}, timeout=60)
    except requests.RequestException as e:
        raise HTTPException(502, f"No hay conexión con n8n: {e}")
    if r.status_code != 200:
        raise HTTPException(502, f"n8n respondió HTTP {r.status_code}: {r.text[:200]}")
    log(f"Renombrado {file_id}: {anterior} -> {nuevo}")
    return {"ok": True, "nombre": nuevo}


@app.get("/api/limites")
def limites():
    return LIMITES


@app.post("/api/revisar")
def revisar(d: dict):
    """Descarga (o toma de la caché) cada video y lo mide con ffprobe: duración, peso y bitrate de audio."""
    from concurrent.futures import ThreadPoolExecutor
    n8n("videos")  # revisa que haya configuración

    def uno(v):
        try:
            ruta = obtener_original(v["id"], v.get("modificado", ""), v.get("nombre", ""))
            return v["id"], info_video(ruta)
        except Exception as e:
            return v["id"], {"error": str(e)}

    with ThreadPoolExecutor(MAX_REVISIONES_A_LA_VEZ) as ex:
        return {"info": dict(ex.map(uno, [v for v in d.get("videos", []) if v.get("id")]))}


@app.post("/api/mover")
def mover(d: dict):
    """Mueve los videos a la carpeta «Videos Subidos» (la carpeta destino está en el flujo de n8n)."""
    n8n("videos")
    movidos, errores = [], []
    for v in d.get("videos", []):
        if not v.get("id"):
            continue
        with candado:
            if any(t["fileId"] == v["id"] and t["estado"] in ESTADOS_ACTIVOS for t in trabajos.values()):
                errores.append(f"{v.get('nombre', v['id'])}: se está procesando, espera a que termine")
                continue
        try:
            n8n_json("mover", "POST", json={"fileId": v["id"], "carpetaId": v.get("carpetaId", "")})
            movidos.append(v["id"])
            borrar_cache_de(v["id"])
            log(f"Movido a Videos Subidos: {v.get('nombre', '')} ({v['id']})")
        except Exception as e:
            errores.append(f"{v.get('nombre', v['id'])}: {e}")
    return {"ok": not errores, "movidos": movidos, "errores": errores}


@app.get("/api/perfiles")
def perfiles():
    """Todas las cuentas conectadas en Hootsuite (para elegir cuáles se usan)."""
    try:
        d = n8n_json("perfiles")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, str(e))
    for p in d.get("perfiles", []):
        p["red"] = TIPOS_HOOTSUITE.get(str(p.get("tipo", "")).upper())
    return d


@app.get("/api/cuentas")
def ver_cuentas(recargar: bool = False):
    return {"cuentas": resolver_cuentas(forzar=recargar)}


@app.post("/api/publicar")
async def publicar(req: Request):
    d = await req.json()
    vids = d.get("videos") or []
    fecha = d.get("fecha")
    if not vids:
        raise HTTPException(400, "No hay videos para publicar.")
    n8n("videos")  # revisa que haya configuración
    creados = []
    with candado:
        for v in vids:
            if not v.get("id") or not v.get("cuentas"):
                continue
            if any(t["fileId"] == v["id"] and t["estado"] in ESTADOS_ACTIVOS for t in trabajos.values()):
                continue   # ese video ya se está procesando
            tid = uuid.uuid4().hex[:10]
            trabajos[tid] = {"id": tid, "tipo": "publicar", "fileId": v["id"], "nombre": v.get("nombre", ""),
                             "estado": "en_cola", "mensaje": "En cola…", "inicio": time.time()}
            creados.append((tid, v))
    for tid, v in creados:
        threading.Thread(target=trabajo_publicar, args=(tid, v, fecha), daemon=True).start()
    return {"ok": True, "recibidos": len(creados)}


@app.post("/api/titulo")
async def titulo(req: Request):
    d = await req.json()
    if not d.get("fileId") or not d.get("png"):
        raise HTTPException(400, "Faltan datos")
    n8n("videos")  # revisa que haya configuración antes de empezar
    with candado:
        ocupado = any(t["fileId"] == d["fileId"] and t["estado"] in ESTADOS_ACTIVOS for t in trabajos.values())
        if ocupado:
            raise HTTPException(409, "Ese video ya se está procesando.")
        tid = uuid.uuid4().hex[:10]
        trabajos[tid] = {"id": tid, "tipo": "titulo", "fileId": d["fileId"], "nombre": d.get("nombre", ""), "estado": "en_cola",
                         "mensaje": "En cola…", "inicio": time.time()}
    threading.Thread(target=trabajo_titulo, daemon=True,
                     args=(tid, d["fileId"], d.get("nombre", ""), d.get("modificado", ""),
                           max(0.0, float(d.get("desde") or 0)), d["png"])).start()
    return {"ok": True, "trabajo": tid}


@app.get("/api/trabajos")
def ver_trabajos():
    ahora = time.time()
    with candado:
        for k in [k for k, t in trabajos.items() if t.get("fin") and ahora - t["fin"] > 600]:
            trabajos.pop(k, None)
        return {"trabajos": list(trabajos.values())}


@app.post("/api/cerrar")
def cerrar():
    threading.Timer(0.5, lambda: os._exit(0)).start()
    return {"ok": True}


def main():
    for p in CACHE_VIDEOS.glob("*.parcial"):     # descargas que quedaron a medias
        p.unlink(missing_ok=True)
    puerto = int(leer_config().get("puerto", 7880))
    uvicorn.run(app, host="127.0.0.1", port=puerto, log_level="warning")


if __name__ == "__main__":
    main()
