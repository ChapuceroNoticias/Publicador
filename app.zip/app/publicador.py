"""
Publicador · El Chapucero  (servidor local)
-------------------------------------------
- Muestra el panel en el navegador (http://127.0.0.1:7880).
- Habla con el n8n de Render por webhooks (con la clave X-Clave):
      GET  {n8n}/videos              lista de videos de la carpeta de Drive
      GET  {n8n}/descargar?id=...    el video original
      GET  {n8n}/miniatura?id=...    miniatura (respaldo si Google no la entrega directo)
      POST {n8n}/subida              crea una subida directa a Drive (reemplaza el archivo, mismo ID)
      POST {n8n}/renombrar           cambia el nombre del archivo en Drive
      POST {n8n}/hs-media            crea la subida del video en Hootsuite (el video se sube directo desde la PC)
      GET  {n8n}/hs-media-estado     revisa si Hootsuite ya procesó el video (READY)
      POST {n8n}/hs-mensaje          crea la publicación en las cuentas de la carpeta del video
      GET  {n8n}/perfiles            cuentas conectadas en Hootsuite (para ver sus IDs)
- Los videos que se ven o se editan se guardan en caché en esta PC (se descargan una sola vez).
- El cambio de título se renderiza AQUÍ con ffmpeg (NVENC si hay tarjeta NVIDIA).
"""
import base64
import hashlib
import json
import mimetypes
import os
import shutil
import subprocess
import tempfile
import threading
import time
import traceback
import uuid
from pathlib import Path

import requests
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response

APP = Path(__file__).resolve().parent
RAIZ = APP.parent
CONFIG_PATH = RAIZ / "config.json"
DATOS = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "PublicadorChapucero"
TRABAJOS_DIR = DATOS / "trabajos"
CACHE_VIDEOS = DATOS / "cache_videos"
CACHE_MINIS = DATOS / "cache_miniaturas"
for d in (TRABAJOS_DIR, CACHE_VIDEOS, CACHE_MINIS):
    d.mkdir(parents=True, exist_ok=True)
LOG = DATOS / "registro.log"
SIN_VENTANA = 0x08000000 if os.name == "nt" else 0
CACHE_MAX_GB = 5          # tamaño máximo de la caché de videos
CACHE_MAX_ARCHIVOS = 30

# Límites por red al publicar a través de Hootsuite (duración en segundos, peso en MB, texto en caracteres).
# Si una red cambia sus límites, se ajusta aquí y se manda la actualización.
LIMITES = {
    "facebook":  {"nombre": "Facebook",  "dur_min": 3,   "dur_max": 90,  "mb": 1024, "texto": 63206},
    "instagram": {"nombre": "Instagram", "dur_min": 3,   "dur_max": 900, "mb": 300,  "texto": 2200},
    "x":         {"nombre": "X",         "dur_min": 0.5, "dur_max": 140, "mb": 512,  "texto": 280},
}
MAX_PUBLICACIONES_A_LA_VEZ = 2
ESTADOS_ACTIVOS = ("en_cola", "descargando", "renderizando", "subiendo", "validando", "subiendo_hs", "procesando_hs", "programando")

POR_DEFECTO = {
    "n8n_url": "",          # ej. https://tu-n8n.onrender.com/webhook  (o /webhook-test para pruebas)
    "clave": "",            # la misma que la credencial "Header Auth" de n8n
    "puerto": 7880,
    "gpu_nvenc": False,
    "url_actualizacion": "",
}

app = FastAPI(title="Publicador Chapucero")
trabajos = {}               # id -> {estado, mensaje, fileId, nombre, inicio}
candado = threading.Lock()
candados_descarga = {}      # fileId -> Lock (para no bajar el mismo video dos veces a la vez)
cupo_publicar = threading.Semaphore(MAX_PUBLICACIONES_A_LA_VEZ)


# ----------------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------------
def log(txt):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S  ") + txt + "\n")
    except OSError:
        pass


def leer_config():
    cfg = dict(POR_DEFECTO)
    if CONFIG_PATH.exists():
        try:
            cfg.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig")))
        except Exception:
            pass
    return cfg


def guardar_config(cambios):
    cfg = leer_config()
    cfg.update(cambios)
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return cfg


def n8n(ruta):
    cfg = leer_config()
    base = (cfg.get("n8n_url") or "").strip().rstrip("/")
    if not base or not cfg.get("clave"):
        raise HTTPException(400, "config")
    return base + "/" + ruta.lstrip("/"), {"X-Clave": cfg["clave"]}


def actualizar_trabajo(tid, **datos):
    with candado:
        trabajos[tid].update(datos)


def llave(file_id, modificado):
    """Nombre de caché: cambia cuando el archivo cambia en Drive."""
    h = hashlib.md5(f"{file_id}|{modificado or ''}".encode()).hexdigest()[:10]
    return f"{file_id}_{h}"


def limpiar_cache():
    archivos = sorted((p for p in CACHE_VIDEOS.glob("*") if p.is_file() and not p.name.endswith(".parcial")),
                      key=lambda p: p.stat().st_atime, reverse=True)
    total = 0
    for i, p in enumerate(archivos):
        total += p.stat().st_size
        if i >= CACHE_MAX_ARCHIVOS or total > CACHE_MAX_GB * 1024 ** 3:
            p.unlink(missing_ok=True)


def borrar_cache_de(file_id):
    for p in list(CACHE_VIDEOS.glob(f"{file_id}_*")) + list(CACHE_MINIS.glob(f"{file_id}_*")):
        p.unlink(missing_ok=True)


def obtener_original(file_id, modificado, nombre):
    """Regresa la ruta local del video (lo descarga de n8n solo si no está en caché)."""
    ext = Path(nombre or "video.mp4").suffix.lower() or ".mp4"
    destino = CACHE_VIDEOS / f"{llave(file_id, modificado)}{ext}"
    with candado:
        lk = candados_descarga.setdefault(file_id, threading.Lock())
    with lk:
        if destino.exists() and destino.stat().st_size > 1000:
            os.utime(destino)
            return destino
        for viejo in CACHE_VIDEOS.glob(f"{file_id}_*"):   # versiones anteriores del mismo archivo
            viejo.unlink(missing_ok=True)
        parcial = destino.with_name(destino.name + ".parcial")
        url, hdr = n8n("descargar")
        with requests.get(url, headers=hdr, params={"id": file_id}, stream=True, timeout=(15, 600)) as r:
            if r.status_code != 200:
                raise RuntimeError(f"n8n no entregó el video (HTTP {r.status_code}): {r.text[:200]}")
            with open(parcial, "wb") as f:
                for trozo in r.iter_content(1024 * 1024):
                    f.write(trozo)
        if parcial.stat().st_size < 1000:
            parcial.unlink(missing_ok=True)
            raise RuntimeError("El video descargado está vacío.")
        parcial.replace(destino)
    limpiar_cache()
    return destino


def medidas(ruta):
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height", "-of", "json", str(ruta)],
        capture_output=True, text=True, creationflags=SIN_VENTANA)
    if r.returncode != 0:
        raise RuntimeError("No se pudo leer el video descargado: " + r.stderr[-300:])
    s = json.loads(r.stdout)["streams"][0]
    return int(s["width"]), int(s["height"])


def duracion(ruta):
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", str(ruta)],
        capture_output=True, text=True, creationflags=SIN_VENTANA)
    try:
        return float(json.loads(r.stdout)["format"]["duration"])
    except Exception:
        raise RuntimeError("No se pudo leer la duración del video.")


def fmt_tiempo(seg):
    seg = int(round(seg))
    return f"{seg // 60}:{seg % 60:02d}"


def problemas_por_red(red, dur, mb, texto):
    """Lista de motivos por los que el video NO se puede mandar a esa red (vacía = sí se puede)."""
    L = LIMITES[red]
    p = []
    if dur is not None and dur > L["dur_max"]:
        p.append(f"dura {fmt_tiempo(dur)} y el máximo es {fmt_tiempo(L['dur_max'])}")
    if dur is not None and dur < L["dur_min"]:
        p.append(f"dura {dur:.1f} s y el mínimo es {L['dur_min']} s")
    if mb is not None and mb > L["mb"]:
        p.append(f"pesa {mb:.0f} MB y el máximo es {L['mb']} MB")
    if texto is not None and len(texto) > L["texto"]:
        p.append(f"el texto tiene {len(texto)} caracteres y el máximo es {L['texto']}")
    return p


def n8n_json(ruta, metodo="GET", **kw):
    url, hdr = n8n(ruta)
    r = requests.request(metodo, url, headers=hdr, timeout=kw.pop("timeout", 60), **kw)
    try:
        d = r.json()
    except ValueError:
        d = {}
    if r.status_code != 200 or d.get("ok") is False:
        raise RuntimeError(d.get("error") or f"n8n respondió HTTP {r.status_code}: {r.text[:200]}")
    return d


def codificador():
    if leer_config().get("gpu_nvenc"):
        return ["-c:v", "h264_nvenc", "-preset", "p5", "-cq", "19", "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p"]


def renderizar(video, capa, salida, desde):
    """Pone la capa (barra roja + título, PNG 1080x1920) sobre el video, escalada al ancho y pegada arriba."""
    W, _ = medidas(video)
    activar = f":enable='gte(t,{desde:.3f})'" if desde > 0 else ""
    filtro = f"[1:v]scale={W}:-1[t];[0:v][t]overlay=0:0{activar}[v]"
    base = ["ffmpeg", "-y", "-v", "error", "-i", str(video), "-i", str(capa),
            "-filter_complex", filtro, "-map", "[v]", "-map", "0:a?"]
    fin = ["-c:a", "copy", "-movflags", "+faststart", str(salida)]
    r = subprocess.run(base + codificador() + fin, capture_output=True, text=True, creationflags=SIN_VENTANA)
    if r.returncode != 0 and leer_config().get("gpu_nvenc"):
        log("NVENC falló, reintento con el procesador: " + r.stderr[-300:])
        r = subprocess.run(base + ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p"] + fin,
                           capture_output=True, text=True, creationflags=SIN_VENTANA)
    if r.returncode != 0 or not Path(salida).exists():
        raise RuntimeError("ffmpeg falló: " + r.stderr[-500:])


# ----------------------------------------------------------------------------
# Trabajo de cambio de título (en segundo plano)
# ----------------------------------------------------------------------------
def trabajo_titulo(tid, file_id, nombre, modificado, desde, png_b64):
    carpeta = Path(tempfile.mkdtemp(prefix="titulo_", dir=TRABAJOS_DIR))
    try:
        capa = carpeta / "capa.png"
        capa.write_bytes(base64.b64decode(png_b64))
        salida = carpeta / "salida.mp4"

        # 1) Original (de la caché, o se descarga a través de n8n)
        actualizar_trabajo(tid, estado="descargando", mensaje="Descargando video…")
        original = obtener_original(file_id, modificado, nombre)

        # 2) Renderizar
        actualizar_trabajo(tid, estado="renderizando", mensaje="Poniendo el título…")
        renderizar(original, capa, salida, desde)

        # 3) Pedir a n8n una subida directa a Drive y subir (reemplaza el archivo, mismo ID)
        actualizar_trabajo(tid, estado="subiendo", mensaje="Subiendo a Drive…")
        tam = salida.stat().st_size
        url, hdr = n8n("subida")
        r = requests.post(url, headers=hdr, json={"fileId": file_id, "tamano": tam, "mimeType": "video/mp4"}, timeout=60)
        if r.status_code != 200:
            raise RuntimeError(f"n8n no creó la subida (HTTP {r.status_code}): {r.text[:200]}")
        upload_url = (r.json() or {}).get("uploadUrl")
        if not upload_url:
            raise RuntimeError("n8n no regresó la dirección de subida.")
        with open(salida, "rb") as f:
            r = requests.put(upload_url, data=f, headers={"Content-Length": str(tam), "Content-Type": "video/mp4"},
                             timeout=(15, 1800))
        if r.status_code not in (200, 201):
            raise RuntimeError(f"Drive rechazó la subida (HTTP {r.status_code}): {r.text[:200]}")

        borrar_cache_de(file_id)   # el archivo cambió: la próxima vez se ve la versión nueva
        actualizar_trabajo(tid, estado="listo", mensaje="Título cambiado ✓", fin=time.time())
        log(f"Título cambiado: {nombre} ({file_id})")
    except Exception as e:
        log(f"Error cambiando título de {nombre}: {traceback.format_exc()}")
        actualizar_trabajo(tid, estado="error", mensaje=str(e), fin=time.time())
    finally:
        shutil.rmtree(carpeta, ignore_errors=True)


# ----------------------------------------------------------------------------
# Trabajo de publicación (en segundo plano)
# ----------------------------------------------------------------------------
def trabajo_publicar(tid, v, fecha):
    file_id, nombre = v["id"], v.get("nombre", "")
    redes = [r for r in v.get("redes", []) if r in LIMITES]
    texto = v.get("texto", "")
    try:
        actualizar_trabajo(tid, estado="en_cola", mensaje="Esperando turno para publicar…")
        with cupo_publicar:
            # 1) Video (de la caché o descargado una vez)
            actualizar_trabajo(tid, estado="descargando", mensaje="Preparando video…")
            ruta = obtener_original(file_id, v.get("modificado", ""), nombre)

            # 2) Validación final con el archivo real
            actualizar_trabajo(tid, estado="validando", mensaje="Revisando límites…")
            dur, tam = duracion(ruta), ruta.stat().st_size
            omitidas, permitidas = [], []
            for red in redes:
                p = problemas_por_red(red, dur, tam / 1024 / 1024, texto)
                (omitidas if p else permitidas).append((red, p))
            permitidas = [r for r, _ in permitidas]
            nota = "; ".join(f"{LIMITES[r]['nombre']}: {', '.join(p)}" for r, p in omitidas)
            if not permitidas:
                raise RuntimeError("No se puede publicar en ninguna red. " + nota)

            # 3) Subida a Hootsuite (directo desde esta PC)
            actualizar_trabajo(tid, estado="subiendo_hs", mensaje="Subiendo a Hootsuite…")
            mime = mimetypes.guess_type(str(ruta))[0] or "video/mp4"
            d = n8n_json("hs-media", "POST", json={"sizeBytes": tam, "mimeType": mime})
            media_id, upload_url = d.get("id"), d.get("uploadUrl")
            if not media_id or not upload_url:
                raise RuntimeError("Hootsuite no entregó la dirección de subida.")
            with open(ruta, "rb") as f:
                r = requests.put(upload_url, data=f, timeout=(15, 1800),
                                 headers={"Content-Type": mime, "Content-Length": str(tam)})
            if r.status_code not in (200, 201, 204):
                raise RuntimeError(f"Hootsuite rechazó el video (HTTP {r.status_code}).")

            # 4) Esperar a que Hootsuite lo procese
            actualizar_trabajo(tid, estado="procesando_hs", mensaje="Hootsuite procesando el video…")
            limite = time.time() + 600
            while True:
                estado = (n8n_json("hs-media-estado", params={"id": media_id}).get("state") or "").upper()
                if estado == "READY":
                    break
                if estado in ("FAILED", "ERROR", "REJECTED"):
                    raise RuntimeError(f"Hootsuite no pudo procesar el video ({estado}).")
                if time.time() > limite:
                    raise RuntimeError("Hootsuite tardó más de 10 minutos en procesar el video.")
                time.sleep(5)

            # 5) Crear la publicación
            actualizar_trabajo(tid, estado="programando", mensaje="Creando la publicación…")
            d = n8n_json("hs-mensaje", "POST", timeout=120, json={
                "mediaId": media_id, "texto": texto, "carpeta": v.get("carpeta", ""),
                "redes": permitidas, "fecha": fecha, "nombre": nombre})
            nombres = ", ".join(LIMITES[r]["nombre"] for r in permitidas)
            msg = (f"Programado en {nombres}" if fecha else f"Enviado a {nombres}") + " ✓"
            if nota:
                msg += f" (no se mandó a {nota})"
            actualizar_trabajo(tid, estado="listo", mensaje=msg, fin=time.time(), detalle=d)
            log(f"Publicado {nombre} ({file_id}) en {permitidas}. Omitidas: {nota or '-'}")
    except Exception as e:
        log(f"Error publicando {nombre}: {traceback.format_exc()}")
        actualizar_trabajo(tid, estado="error", mensaje=str(e), fin=time.time())


# ----------------------------------------------------------------------------
# Rutas
# ----------------------------------------------------------------------------
@app.get("/")
def inicio():
    return FileResponse(APP / "web" / "panel.html", headers={"Cache-Control": "no-store"})


@app.get("/assets/{nombre}")
def assets(nombre: str):
    ruta = (APP / "assets" / nombre).resolve()
    if not str(ruta).startswith(str((APP / "assets").resolve())) or not ruta.exists():
        raise HTTPException(404)
    return FileResponse(ruta)


@app.get("/api/vivo")
def vivo():
    return {"ok": True, "version": (APP / "version.txt").read_text(encoding="utf-8").strip()}


@app.get("/api/config")
def ver_config():
    cfg = leer_config()
    return {"n8n_url": cfg.get("n8n_url", ""), "tiene_clave": bool(cfg.get("clave")),
            "gpu_nvenc": cfg.get("gpu_nvenc", False),
            "version": (APP / "version.txt").read_text(encoding="utf-8").strip()}


@app.post("/api/config")
async def cambiar_config(req: Request):
    d = await req.json()
    cambios = {}
    if "n8n_url" in d:
        cambios["n8n_url"] = str(d["n8n_url"]).strip().rstrip("/")
    if d.get("clave"):
        cambios["clave"] = str(d["clave"]).strip()
    guardar_config(cambios)
    return ver_config()


@app.get("/api/videos")
def videos():
    url, hdr = n8n("videos")
    try:
        r = requests.get(url, headers=hdr, timeout=60)
    except requests.RequestException as e:
        raise HTTPException(502, f"No hay conexión con n8n: {e}")
    if r.status_code in (401, 403):
        raise HTTPException(401, "La clave no es correcta.")
    if r.status_code != 200:
        raise HTTPException(502, f"n8n respondió HTTP {r.status_code}")
    return JSONResponse(r.json())


@app.get("/api/miniatura/{file_id}")
def miniatura(file_id: str, m: str = "", u: str = ""):
    """Miniatura con caché local. Primero intenta directo con Google; si no, a través de n8n."""
    ruta = CACHE_MINIS / f"{llave(file_id, m)}.img"
    if not ruta.exists():
        datos, tipo = None, "image/jpeg"
        if u:
            try:
                r = requests.get(u.split("=s")[0] + "=s480" if "=s" in u else u, timeout=15)
                if r.status_code == 200 and r.headers.get("content-type", "").startswith("image/"):
                    datos, tipo = r.content, r.headers["content-type"]
            except requests.RequestException:
                pass
        if datos is None:
            try:
                url, hdr = n8n("miniatura")
                r = requests.get(url, headers=hdr, params={"id": file_id}, timeout=30)
                if r.status_code == 200 and r.headers.get("content-type", "").startswith("image/"):
                    datos, tipo = r.content, r.headers["content-type"]
            except (requests.RequestException, HTTPException):
                pass
        if datos is None:
            raise HTTPException(404, "Sin miniatura")
        for viejo in CACHE_MINIS.glob(f"{file_id}_*"):
            viejo.unlink(missing_ok=True)
        ruta.write_bytes(datos)
        ruta.with_suffix(".tipo").write_text(tipo)
    tipo_p = ruta.with_suffix(".tipo")
    tipo = tipo_p.read_text() if tipo_p.exists() else "image/jpeg"
    return Response(ruta.read_bytes(), media_type=tipo, headers={"Cache-Control": "max-age=86400"})


@app.get("/api/ver/{file_id}")
def ver(file_id: str, m: str = "", nombre: str = "video.mp4"):
    """Entrega el video para el reproductor (lo descarga una vez y queda en caché)."""
    try:
        ruta = obtener_original(file_id, m, nombre)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, str(e))
    tipo = mimetypes.guess_type(str(ruta))[0] or "video/mp4"
    return FileResponse(ruta, media_type=tipo)


@app.post("/api/renombrar")
async def renombrar(req: Request):
    d = await req.json()
    file_id = d.get("fileId")
    nuevo = str(d.get("nombre") or "").strip()
    anterior = str(d.get("anterior") or "")
    if not file_id or not nuevo:
        raise HTTPException(400, "Falta el nombre")
    for c in '\\/:*?"<>|':
        nuevo = nuevo.replace(c, "-")
    ext = Path(anterior).suffix
    if ext and not nuevo.lower().endswith(ext.lower()):
        nuevo += ext
    url, hdr = n8n("renombrar")
    try:
        r = requests.post(url, headers=hdr, json={"fileId": file_id, "nombre": nuevo}, timeout=60)
    except requests.RequestException as e:
        raise HTTPException(502, f"No hay conexión con n8n: {e}")
    if r.status_code != 200:
        raise HTTPException(502, f"n8n respondió HTTP {r.status_code}: {r.text[:200]}")
    log(f"Renombrado {file_id}: {anterior} -> {nuevo}")
    return {"ok": True, "nombre": nuevo}


@app.get("/api/limites")
def limites():
    return LIMITES


@app.get("/api/perfiles")
def perfiles():
    try:
        return n8n_json("perfiles")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, str(e))


@app.post("/api/publicar")
async def publicar(req: Request):
    d = await req.json()
    vids = d.get("videos") or []
    fecha = d.get("fecha")
    if not vids:
        raise HTTPException(400, "No hay videos para publicar.")
    n8n("videos")  # revisa que haya configuración
    creados = []
    with candado:
        for v in vids:
            if not v.get("id") or not v.get("redes"):
                continue
            if any(t["fileId"] == v["id"] and t["estado"] in ESTADOS_ACTIVOS for t in trabajos.values()):
                continue   # ese video ya se está procesando
            tid = uuid.uuid4().hex[:10]
            trabajos[tid] = {"id": tid, "tipo": "publicar", "fileId": v["id"], "nombre": v.get("nombre", ""),
                             "estado": "en_cola", "mensaje": "En cola…", "inicio": time.time()}
            creados.append((tid, v))
    for tid, v in creados:
        threading.Thread(target=trabajo_publicar, args=(tid, v, fecha), daemon=True).start()
    return {"ok": True, "recibidos": len(creados)}


@app.post("/api/titulo")
async def titulo(req: Request):
    d = await req.json()
    if not d.get("fileId") or not d.get("png"):
        raise HTTPException(400, "Faltan datos")
    n8n("videos")  # revisa que haya configuración antes de empezar
    with candado:
        ocupado = any(t["fileId"] == d["fileId"] and t["estado"] in ESTADOS_ACTIVOS for t in trabajos.values())
        if ocupado:
            raise HTTPException(409, "Ese video ya se está procesando.")
        tid = uuid.uuid4().hex[:10]
        trabajos[tid] = {"id": tid, "tipo": "titulo", "fileId": d["fileId"], "nombre": d.get("nombre", ""), "estado": "en_cola",
                         "mensaje": "En cola…", "inicio": time.time()}
    threading.Thread(target=trabajo_titulo, daemon=True,
                     args=(tid, d["fileId"], d.get("nombre", ""), d.get("modificado", ""),
                           max(0.0, float(d.get("desde") or 0)), d["png"])).start()
    return {"ok": True, "trabajo": tid}


@app.get("/api/trabajos")
def ver_trabajos():
    ahora = time.time()
    with candado:
        for k in [k for k, t in trabajos.items() if t.get("fin") and ahora - t["fin"] > 600]:
            trabajos.pop(k, None)
        return {"trabajos": list(trabajos.values())}


@app.post("/api/cerrar")
def cerrar():
    threading.Timer(0.5, lambda: os._exit(0)).start()
    return {"ok": True}


def main():
    for p in CACHE_VIDEOS.glob("*.parcial"):     # descargas que quedaron a medias
        p.unlink(missing_ok=True)
    puerto = int(leer_config().get("puerto", 7880))
    uvicorn.run(app, host="127.0.0.1", port=puerto, log_level="warning")


if __name__ == "__main__":
    main()
